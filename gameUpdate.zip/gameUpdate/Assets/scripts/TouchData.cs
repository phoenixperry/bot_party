﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TouchData : MonoBehaviour
{


    //    //this class handles all of the touches between boxes 

    public static string touchingBoxes; //what boxes are touching 
    public static int touch = 0; //touch state 
    public GameObject bot1;
    public GameObject bot2;
    public GameObject bot3;
    public AudioClip onetwo;
    public AudioClip twothree;
    public AudioClip onethree;
    public AudioClip allthree;
    public ArrayList touchsound = new ArrayList();

    private void Start()
    {
        gameObject.GetComponent<AudioSource>().playOnAwake = false;
        touchsound.Add(onetwo);
        touchsound.Add(twothree);
        
    }


    public void updateData(string value)
    {
        string[] sensors = value.Split(' '); //split the stinrg we got from arduino using a space as the delimiter of the string 
        touchingBoxes = sensors[0]; //the first value indicate which boxes are are testing for being connected 
        int.TryParse(sensors[1], out touch); //get the string value of the touch state and convert it to an int for sanity
                                             //Debug.Log("Touch Parsed: " + touchingBoxes + " touch state " +touch);

        if (touchingBoxes == "BoxOneTwo" && touch == 1)
        {
            gameObject.GetComponent<AudioSource>().clip = touchsound[0] as AudioClip;
            gameObject.GetComponent<AudioSource>().Play();
        }
        else if (touchingBoxes == "BowTwoThree" && touch == 1)
        {
            gameObject.GetComponent<AudioSource>().clip = touchsound[1] as AudioClip;
            gameObject.GetComponent<AudioSource>().Play();
        }
        else if (touchingBoxes == "BoxOneThree" && touch == 1)
        {
            gameObject.GetComponent<AudioSource>().clip = touchsound[2] as AudioClip;
            gameObject.GetComponent<AudioSource>().Play();
        }
        else if (touchingBoxes == "AllBoxes" && touch == 1 )
        {
            gameObject.GetComponent<AudioSource>().clip = touchsound[3] as AudioClip;
            gameObject.GetComponent<AudioSource>().Play();
        }
     }
}